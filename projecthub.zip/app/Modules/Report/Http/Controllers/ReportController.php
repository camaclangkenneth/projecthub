<?php

namespace App\Modules\Report\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Controllers\Controller;

class ReportController extends Controller
{
    //
}
